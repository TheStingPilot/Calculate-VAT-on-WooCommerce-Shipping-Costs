<?php
/**
 * WooCommerce integration.
 *
 * @package WCProRataShippingVAT
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Main plugin class.
 */
class WCPRSV_Plugin {
	/**
	 * Singleton instance.
	 *
	 * @var WCPRSV_Plugin|null
	 */
	private static $instance = null;

	/**
	 * Settings service.
	 *
	 * @var WCPRSV_Settings
	 */
	private $settings;

	/**
	 * Calculator service.
	 *
	 * @var WCPRSV_Calculator
	 */
	private $calculator;

	/**
	 * Get singleton instance.
	 *
	 * @return WCPRSV_Plugin
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		$this->settings   = new WCPRSV_Settings();
		$this->calculator = new WCPRSV_Calculator();
	}

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function init() {
		$this->settings->init();

		add_filter( 'woocommerce_package_rates', array( $this, 'recalculate_package_rates' ), 100, 2 );
		add_action( 'woocommerce_checkout_create_order_shipping_item', array( $this, 'set_order_shipping_item_taxes' ), 20, 4 );
		add_action( 'woocommerce_checkout_create_order', array( $this, 'store_order_breakdown' ), 20, 2 );
		add_action( 'woocommerce_store_api_checkout_order_processed', array( $this, 'finalize_store_api_order' ), 20, 1 );
		add_action( 'woocommerce_checkout_order_processed', array( $this, 'finalize_classic_order' ), 20, 3 );
		add_action( 'woocommerce_cart_totals_after_order_total', array( $this, 'render_classic_breakdown' ) );
		add_action( 'woocommerce_review_order_after_order_total', array( $this, 'render_classic_breakdown' ) );
		add_action( 'woocommerce_order_details_after_order_table', array( $this, 'render_order_breakdown' ) );
		add_action( 'wpo_wcpdf_after_order_details', array( $this, 'render_pdf_invoice_breakdown' ), 10, 2 );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_frontend_assets' ) );
		add_action( 'rest_api_init', array( $this, 'register_storefront_endpoint' ) );
	}

	/**
	 * Recalculate shipping rate costs and taxes for a package.
	 *
	 * @param array $rates Shipping rates.
	 * @param array $package Package data.
	 * @return array
	 */
	public function recalculate_package_rates( $rates, $package ) {
		if ( ! $this->settings->is_enabled() || ! wc_tax_enabled() ) {
			return $rates;
		}

		$goods_by_tax_rate = $this->get_goods_by_tax_rate( $package );

		if ( empty( $goods_by_tax_rate ) ) {
			return $rates;
		}

		foreach ( $rates as $rate_id => $rate ) {
			if ( ! is_a( $rate, 'WC_Shipping_Rate' ) ) {
				continue;
			}

			$cost = (float) $rate->get_cost();

			if ( $cost <= 0 ) {
				continue;
			}

			$result = $this->calculator->calculate(
				$cost,
				$this->settings->get_reference_vat_rate(),
				$goods_by_tax_rate,
				wc_get_price_decimals()
			);

			if ( empty( $result['lines'] ) ) {
				continue;
			}

			$this->debug_log(
				'package_rate_calculated',
				array(
					'rate_id'                => $rate_id,
					'original_rate_cost'     => $cost,
					'reference_vat_rate'     => $this->settings->get_reference_vat_rate(),
					'goods_by_tax_rate'      => $goods_by_tax_rate,
					'calculated_breakdown'   => $result,
				)
			);

			$rate->set_cost( wc_format_decimal( $result['shipping_excluding_vat'], wc_get_price_decimals() ) );
			$rate->set_taxes( $result['taxes'] );
			$rate->add_meta_data( '_wcprsv_breakdown', $result );
			$this->store_session_breakdown( $rate_id, $result );

			$rates[ $rate_id ] = $rate;
		}

		return $rates;
	}

	/**
	 * Persist the pro-rata shipping totals on the order shipping item.
	 *
	 * @param WC_Order_Item_Shipping $item Shipping item.
	 * @param string                 $package_key Package key.
	 * @param array                  $package Shipping package.
	 * @param WC_Order               $order Order object.
	 * @return void
	 */
	public function set_order_shipping_item_taxes( $item, $package_key, $package, $order ) {
		if ( ! $this->settings->is_enabled() || ! wc_tax_enabled() || ! is_a( $item, 'WC_Order_Item_Shipping' ) ) {
			return;
		}

		$breakdown = $this->get_package_shipping_breakdown( $package_key, $package );

		if ( empty( $breakdown['lines'] ) ) {
			$breakdown = $this->calculate_order_shipping_item_breakdown( $item, $package );
		}

		if ( empty( $breakdown['lines'] ) ) {
			$this->debug_log(
				'checkout_create_order_shipping_item_no_breakdown',
				array(
					'package_key'     => $package_key,
					'item_total'      => $item->get_total(),
					'item_taxes'      => $item->get_taxes(),
					'package_summary' => $this->summarize_package( $package ),
				)
			);
			return;
		}

		$this->debug_log(
			'checkout_create_order_shipping_item_apply',
			array(
				'package_key'       => $package_key,
				'before_item_total' => $item->get_total(),
				'before_item_taxes' => $item->get_taxes(),
				'breakdown'         => $breakdown,
			)
		);

		$item->set_total( wc_format_decimal( $breakdown['shipping_excluding_vat'], wc_get_price_decimals() ) );
		$item->set_taxes(
			array(
				'total' => $breakdown['taxes'],
			)
		);
		$item->update_meta_data( '_wcprsv_breakdown', $breakdown );

		$this->debug_log(
			'checkout_create_order_shipping_item_after',
			array(
				'after_item_total' => $item->get_total(),
				'after_item_taxes' => $item->get_taxes(),
			)
		);
	}

	/**
	 * Calculate the breakdown directly while WooCommerce creates the order shipping item.
	 *
	 * @param WC_Order_Item_Shipping $item Shipping item.
	 * @param array                  $package Shipping package.
	 * @return array
	 */
	private function calculate_order_shipping_item_breakdown( $item, array $package ) {
		$goods_by_tax_rate = $this->get_goods_by_tax_rate( $package );

		if ( empty( $goods_by_tax_rate ) ) {
			return array();
		}

		$item_total = (float) $item->get_total();
		$item_taxes = $item->get_taxes();
		$item_tax_total = 0.0;

		if ( ! empty( $item_taxes['total'] ) && is_array( $item_taxes['total'] ) ) {
			$item_tax_total = array_sum( array_map( 'floatval', $item_taxes['total'] ) );
		}

		if ( $item_tax_total > 0 ) {
			$result = $this->calculator->calculate_from_including_vat(
				$item_total + $item_tax_total,
				$goods_by_tax_rate,
				wc_get_price_decimals()
			);

			$this->debug_log(
				'order_shipping_item_breakdown_from_including',
				array(
					'item_total'        => $item_total,
					'item_tax_total'    => $item_tax_total,
					'goods_by_tax_rate' => $goods_by_tax_rate,
					'breakdown'         => $result,
				)
			);

			return $result;
		}

		$result = $this->calculator->calculate(
			$item_total,
			$this->settings->get_reference_vat_rate(),
			$goods_by_tax_rate,
			wc_get_price_decimals()
		);

		$this->debug_log(
			'order_shipping_item_breakdown_from_reference_rate',
			array(
				'item_total'          => $item_total,
				'reference_vat_rate'  => $this->settings->get_reference_vat_rate(),
				'goods_by_tax_rate'   => $goods_by_tax_rate,
				'breakdown'           => $result,
			)
		);

		return $result;
	}

	/**
	 * Store the final pro-rata breakdown on the order.
	 *
	 * @param WC_Order $order Order object.
	 * @param array    $data Checkout data.
	 * @return void
	 */
	public function store_order_breakdown( $order, $data ) {
		if ( ! $this->settings->is_enabled() || ! wc_tax_enabled() || ! is_a( $order, 'WC_Order' ) ) {
			return;
		}

		$breakdown = $this->get_breakdown_from_order_shipping_items( $order );

		if ( empty( $breakdown['lines'] ) ) {
			$breakdown = $this->get_selected_shipping_breakdown();
		}

		if ( empty( $breakdown['lines'] ) ) {
			return;
		}

		$this->debug_log(
			'checkout_create_order_store_breakdown',
			array(
				'order_id'          => $order->get_id(),
				'order_total_before' => $order->get_total(),
				'shipping_total_before' => $order->get_shipping_total(),
				'shipping_tax_before' => $order->get_shipping_tax(),
				'breakdown'         => $breakdown,
			)
		);

		$this->apply_order_tax_lines( $order, $breakdown );
		$order->update_meta_data( '_wcprsv_breakdown', $breakdown );
	}

	/**
	 * Finalize Store API / Checkout Blocks orders after WooCommerce has built the order.
	 *
	 * @param WC_Order $order Order object.
	 * @return void
	 */
	public function finalize_store_api_order( $order ) {
		$this->finalize_order_shipping_breakdown( $order );
	}

	/**
	 * Finalize classic checkout orders after WooCommerce has built the order.
	 *
	 * @param int      $order_id Order ID.
	 * @param array    $posted_data Posted checkout data.
	 * @param WC_Order $order Order object.
	 * @return void
	 */
	public function finalize_classic_order( $order_id, $posted_data, $order ) {
		$this->finalize_order_shipping_breakdown( $order );
	}

	/**
	 * Apply the cart pro-rata shipping breakdown to the completed order.
	 *
	 * @param WC_Order $order Order object.
	 * @return void
	 */
	private function finalize_order_shipping_breakdown( $order ) {
		if ( ! $this->settings->is_enabled() || ! wc_tax_enabled() || ! is_a( $order, 'WC_Order' ) ) {
			return;
		}

		$breakdown = $this->get_selected_shipping_breakdown();

		if ( empty( $breakdown['lines'] ) ) {
			$breakdown = $this->get_breakdown_from_order_shipping_items( $order );
		}

		if ( empty( $breakdown['lines'] ) ) {
			$this->debug_log(
				'finalize_order_no_breakdown',
				array(
					'order_id'       => $order->get_id(),
					'order_total'    => $order->get_total(),
					'shipping_total' => $order->get_shipping_total(),
					'shipping_tax'   => $order->get_shipping_tax(),
				)
			);
			return;
		}

		$this->debug_log(
			'finalize_order_before_apply',
			array(
				'order_id'              => $order->get_id(),
				'order_total_before'    => $order->get_total(),
				'shipping_total_before' => $order->get_shipping_total(),
				'shipping_tax_before'   => $order->get_shipping_tax(),
				'breakdown'             => $breakdown,
			)
		);

		$this->apply_breakdown_to_order_shipping_items( $order, $breakdown );
		$this->apply_order_tax_lines( $order, $breakdown );
		$order->update_meta_data( '_wcprsv_breakdown', $breakdown );
		$order->calculate_totals( false );
		$order->save();

		$this->debug_log(
			'finalize_order_after_apply',
			array(
				'order_id'             => $order->get_id(),
				'order_total_after'    => $order->get_total(),
				'shipping_total_after' => $order->get_shipping_total(),
				'shipping_tax_after'   => $order->get_shipping_tax(),
				'tax_totals_after'     => $this->summarize_order_tax_items( $order ),
			)
		);
	}

	/**
	 * Apply the pro-rata breakdown to the order's shipping items.
	 *
	 * @param WC_Order $order Order object.
	 * @param array    $breakdown Pro-rata breakdown.
	 * @return void
	 */
	private function apply_breakdown_to_order_shipping_items( $order, array $breakdown ) {
		$shipping_items = $order->get_items( 'shipping' );

		if ( empty( $shipping_items ) ) {
			return;
		}

		$first = true;

		foreach ( $shipping_items as $item ) {
			if ( $first ) {
				$item->set_total( wc_format_decimal( $breakdown['shipping_excluding_vat'], wc_get_price_decimals() ) );
				$item->set_taxes(
					array(
						'total' => $breakdown['taxes'],
					)
				);
				$item->update_meta_data( '_wcprsv_breakdown', $breakdown );
				$item->save();
				$first = false;
				continue;
			}

			$item->set_total( 0 );
			$item->set_taxes( array( 'total' => array() ) );
			$item->save();
		}
	}

	/**
	 * Render the breakdown in classic cart and checkout totals tables.
	 *
	 * @return void
	 */
	public function render_classic_breakdown() {
		if ( ! $this->settings->is_enabled() || ! wc_tax_enabled() ) {
			return;
		}

		$breakdown = $this->get_selected_shipping_breakdown();

		if ( empty( $breakdown['lines'] ) ) {
			return;
		}

		echo '<tr class="wcprsv-vat-breakdown"><td colspan="2">';
		echo $this->get_breakdown_html( $breakdown ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '</td></tr>';
	}

	/**
	 * Render the VAT breakdown on the customer order details page.
	 *
	 * @param WC_Order $order Order object.
	 * @return void
	 */
	public function render_order_breakdown( $order ) {
		if ( ! $this->settings->is_enabled() || ! wc_tax_enabled() || ! is_a( $order, 'WC_Order' ) ) {
			return;
		}

		$breakdown = $this->get_order_breakdown( $order );

		if ( empty( $breakdown['lines'] ) ) {
			return;
		}

		echo $this->get_breakdown_html( $breakdown, $order ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/**
	 * Render the VAT breakdown in WP Overnight PDF invoices.
	 *
	 * @param string   $document_type PDF document type.
	 * @param WC_Order $order Order object.
	 * @return void
	 */
	public function render_pdf_invoice_breakdown( $document_type, $order ) {
		if ( ! $this->settings->is_enabled() || ! wc_tax_enabled() || 'invoice' !== $document_type || ! is_a( $order, 'WC_Order' ) ) {
			return;
		}

		$breakdown = $this->get_order_breakdown( $order );

		if ( empty( $breakdown['lines'] ) ) {
			return;
		}

		echo $this->get_pdf_breakdown_html( $breakdown, $order ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/**
	 * Enqueue frontend assets for Cart and Checkout Blocks.
	 *
	 * @return void
	 */
	public function enqueue_frontend_assets() {
		$should_enqueue_style = is_cart() || is_checkout() || ( function_exists( 'is_view_order_page' ) && is_view_order_page() );
		$should_enqueue_script = is_cart() || is_checkout();

		if ( ! $should_enqueue_style || ! $this->settings->is_enabled() || ! wc_tax_enabled() ) {
			return;
		}

		wp_enqueue_style(
			'wcprsv-frontend',
			plugins_url( 'assets/frontend.css', WCPRSV_FILE ),
			array(),
			WCPRSV_VERSION
		);

		if ( ! $should_enqueue_script ) {
			return;
		}

		wp_enqueue_script(
			'wcprsv-frontend',
			plugins_url( 'assets/frontend.js', WCPRSV_FILE ),
			array(),
			WCPRSV_VERSION,
			true
		);

		wp_localize_script(
			'wcprsv-frontend',
			'wcprsvData',
			array(
				'endpoint' => esc_url_raw( rest_url( 'wcprsv/v1/breakdown' ) ),
				'nonce'    => wp_create_nonce( 'wp_rest' ),
				'debug'    => $this->settings->is_debug_enabled(),
			)
		);
	}

	/**
	 * Register a small storefront endpoint for the block checkout display.
	 *
	 * @return void
	 */
	public function register_storefront_endpoint() {
		register_rest_route(
			'wcprsv/v1',
			'/breakdown',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_breakdown_response' ),
				'permission_callback' => '__return_true',
			)
		);
	}

	/**
	 * Return rendered breakdown data for the current cart.
	 *
	 * @return WP_REST_Response
	 */
	public function get_breakdown_response() {
		if ( function_exists( 'wc_load_cart' ) ) {
			wc_load_cart();
		}

		$breakdown = $this->get_selected_shipping_breakdown();

		return rest_ensure_response(
			array(
				'has_breakdown' => ! empty( $breakdown['lines'] ),
				'html'          => ! empty( $breakdown['lines'] ) ? $this->get_breakdown_html( $breakdown ) : '',
				'debug'         => $this->settings->is_debug_enabled() ? $this->get_frontend_debug_payload( $breakdown ) : null,
			)
		);
	}

	/**
	 * Get the pro-rata breakdown for selected shipping rates.
	 *
	 * @return array
	 */
	private function get_selected_shipping_breakdown() {
		if ( ! WC()->cart || ! WC()->session ) {
			return array();
		}

		$packages       = WC()->shipping() ? WC()->shipping()->get_packages() : array();
		$chosen_methods = WC()->session->get( 'chosen_shipping_methods', array() );
		$combined       = array(
			'shipping_including_vat' => 0.0,
			'shipping_excluding_vat' => 0.0,
			'taxes'                  => array(),
			'lines'                  => array(),
		);

		foreach ( $packages as $package_index => $package ) {
			$chosen_rate_id = $chosen_methods[ $package_index ] ?? '';

			if ( empty( $chosen_rate_id ) || empty( $package['rates'][ $chosen_rate_id ] ) ) {
				continue;
			}

			$breakdown = $this->get_package_shipping_breakdown( $package_index, $package );

			if ( empty( $breakdown['lines'] ) ) {
				continue;
			}

			$combined['shipping_including_vat'] += (float) $breakdown['shipping_including_vat'];
			$combined['shipping_excluding_vat'] += (float) $breakdown['shipping_excluding_vat'];

			foreach ( $breakdown['taxes'] as $tax_rate_id => $tax_amount ) {
				if ( ! isset( $combined['taxes'][ $tax_rate_id ] ) ) {
					$combined['taxes'][ $tax_rate_id ] = 0.0;
				}

				$combined['taxes'][ $tax_rate_id ] += (float) $tax_amount;
			}

			foreach ( $breakdown['lines'] as $tax_rate_id => $line ) {
				if ( ! isset( $combined['lines'][ $tax_rate_id ] ) ) {
					$combined['lines'][ $tax_rate_id ] = $line;
					continue;
				}

				$combined['lines'][ $tax_rate_id ]['goods_amount_ex_vat']    += (float) $line['goods_amount_ex_vat'];
				$combined['lines'][ $tax_rate_id ]['shipping_excluding_vat'] += (float) $line['shipping_excluding_vat'];
				$combined['lines'][ $tax_rate_id ]['shipping_vat']           += (float) $line['shipping_vat'];
				$combined['lines'][ $tax_rate_id ]['shipping_including_vat'] += (float) $line['shipping_including_vat'];
			}
		}

		if ( ! empty( $combined['lines'] ) ) {
			return $combined;
		}

		return $this->calculate_current_cart_breakdown();
	}

	/**
	 * Get the pro-rata breakdown for a selected package shipping rate.
	 *
	 * @param string|int $package_key Package key.
	 * @param array      $package Shipping package.
	 * @return array
	 */
	private function get_package_shipping_breakdown( $package_key, $package ) {
		if ( ! WC()->session ) {
			return array();
		}

		$chosen_methods = WC()->session->get( 'chosen_shipping_methods', array() );
		$chosen_rate_id = $chosen_methods[ $package_key ] ?? '';

		if ( empty( $chosen_rate_id ) && ! empty( $package['rates'] ) && 1 === count( $package['rates'] ) ) {
			$rate_ids = array_keys( $package['rates'] );
			$chosen_rate_id = (string) reset( $rate_ids );
		}

		if ( empty( $chosen_rate_id ) ) {
			return array();
		}

		if ( ! empty( $package['rates'][ $chosen_rate_id ] ) && is_a( $package['rates'][ $chosen_rate_id ], 'WC_Shipping_Rate' ) ) {
			$rate      = $package['rates'][ $chosen_rate_id ];
			$breakdown = $this->get_shipping_rate_meta( $package['rates'][ $chosen_rate_id ], '_wcprsv_breakdown' );

			if ( ! empty( $breakdown['lines'] ) ) {
				return $breakdown;
			}
		}

		$breakdown = $this->get_session_breakdown( $chosen_rate_id );

		if ( ! empty( $breakdown['lines'] ) ) {
			return $breakdown;
		}

		if ( empty( $rate ) ) {
			return array();
		}

		return $this->calculate_package_rate_breakdown( $rate, $package );
	}

	/**
	 * Calculate a package shipping breakdown directly from a rate and package.
	 *
	 * @param WC_Shipping_Rate $rate Shipping rate.
	 * @param array            $package Shipping package.
	 * @return array
	 */
	private function calculate_package_rate_breakdown( $rate, array $package ) {
		$goods_by_tax_rate = $this->get_goods_by_tax_rate( $package );

		if ( empty( $goods_by_tax_rate ) ) {
			return array();
		}

		$rate_cost = (float) $rate->get_cost();
		$rate_tax  = array_sum( array_map( 'floatval', (array) $rate->get_taxes() ) );

		if ( $rate_tax > 0 ) {
			return $this->calculator->calculate_from_including_vat(
				$rate_cost + $rate_tax,
				$goods_by_tax_rate,
				wc_get_price_decimals()
			);
		}

		return $this->calculator->calculate(
			$rate_cost,
			$this->settings->get_reference_vat_rate(),
			$goods_by_tax_rate,
			wc_get_price_decimals()
		);
	}

	/**
	 * Read shipping rate metadata across WooCommerce versions.
	 *
	 * @param WC_Shipping_Rate $rate Shipping rate.
	 * @param string           $key Meta key.
	 * @return mixed
	 */
	private function get_shipping_rate_meta( $rate, $key ) {
		if ( method_exists( $rate, 'get_meta' ) ) {
			return $rate->get_meta( $key );
		}

		if ( ! method_exists( $rate, 'get_meta_data' ) ) {
			return null;
		}

		foreach ( $rate->get_meta_data() as $meta ) {
			if ( is_object( $meta ) && method_exists( $meta, 'get_data' ) ) {
				$data = $meta->get_data();
			} elseif ( is_array( $meta ) ) {
				$data = $meta;
			} else {
				continue;
			}

			if ( isset( $data['key'] ) && $key === $data['key'] ) {
				return $data['value'] ?? null;
			}
		}

		return null;
	}

	/**
	 * Store a shipping breakdown in the session for checkout order creation.
	 *
	 * @param string $rate_id Shipping rate ID.
	 * @param array  $breakdown Pro-rata breakdown.
	 * @return void
	 */
	private function store_session_breakdown( $rate_id, array $breakdown ) {
		if ( ! WC()->session ) {
			return;
		}

		$breakdowns = WC()->session->get( 'wcprsv_shipping_breakdowns', array() );
		$breakdowns[ (string) $rate_id ] = $breakdown;
		WC()->session->set( 'wcprsv_shipping_breakdowns', $breakdowns );
	}

	/**
	 * Retrieve a shipping breakdown from the session.
	 *
	 * @param string $rate_id Shipping rate ID.
	 * @return array
	 */
	private function get_session_breakdown( $rate_id ) {
		if ( ! WC()->session ) {
			return array();
		}

		$breakdowns = WC()->session->get( 'wcprsv_shipping_breakdowns', array() );

		return ! empty( $breakdowns[ (string) $rate_id ]['lines'] ) ? $breakdowns[ (string) $rate_id ] : array();
	}

	/**
	 * Calculate the display breakdown directly from the current cart totals.
	 *
	 * @return array
	 */
	private function calculate_current_cart_breakdown() {
		if ( ! WC()->cart ) {
			return array();
		}

		$goods_by_tax_rate = $this->get_goods_by_tax_rate(
			array(
				'contents' => WC()->cart->get_cart(),
			)
		);

		if ( empty( $goods_by_tax_rate ) ) {
			return array();
		}

		$shipping_including_vat = $this->get_current_shipping_including_vat();

		if ( $shipping_including_vat <= 0 ) {
			return array();
		}

		return $this->calculator->calculate_from_including_vat(
			$shipping_including_vat,
			$goods_by_tax_rate,
			wc_get_price_decimals()
		);
	}

	/**
	 * Build debug payload for browser devtools.
	 *
	 * @param array $breakdown Pro-rata breakdown.
	 * @return array
	 */
	private function get_frontend_debug_payload( array $breakdown ) {
		return array(
			'cart'      => WC()->cart ? array(
				'subtotal'       => WC()->cart->get_subtotal(),
				'total'          => WC()->cart->get_total( 'edit' ),
				'shipping_total' => WC()->cart->get_shipping_total(),
				'shipping_tax'   => WC()->cart->get_shipping_tax(),
				'taxes'          => WC()->cart->get_taxes(),
			) : null,
			'packages'  => WC()->shipping() ? $this->summarize_packages( WC()->shipping()->get_packages() ) : array(),
			'breakdown' => $breakdown,
		);
	}

	/**
	 * Get selected shipping including VAT from cart totals or selected package rates.
	 *
	 * @return float
	 */
	private function get_current_shipping_including_vat() {
		$shipping_including_vat = (float) WC()->cart->get_shipping_total() + (float) WC()->cart->get_shipping_tax();

		if ( $shipping_including_vat > 0 ) {
			return $shipping_including_vat;
		}

		if ( ! WC()->shipping() || ! WC()->session ) {
			return 0.0;
		}

		$packages       = WC()->shipping()->get_packages();
		$chosen_methods = WC()->session->get( 'chosen_shipping_methods', array() );

		foreach ( $packages as $package_index => $package ) {
			$chosen_rate_id = $chosen_methods[ $package_index ] ?? '';

			if ( empty( $chosen_rate_id ) || empty( $package['rates'][ $chosen_rate_id ] ) ) {
				continue;
			}

			$rate = $package['rates'][ $chosen_rate_id ];

			if ( ! is_a( $rate, 'WC_Shipping_Rate' ) ) {
				continue;
			}

			$shipping_including_vat += (float) $rate->get_cost() + array_sum( $rate->get_taxes() );
		}

		return $shipping_including_vat;
	}

	/**
	 * Build the customer-facing breakdown HTML.
	 *
	 * @param array $breakdown Pro-rata breakdown.
	 * @return string
	 */
	private function get_breakdown_html( array $breakdown, $order = null ) {
		$display_lines      = $this->get_display_lines( $breakdown['lines'], $breakdown, $order );
		$goods_total        = $this->sum_display_column( $display_lines, 'goods_amount_ex_vat' );
		$shipping_total     = $this->sum_display_column( $display_lines, 'shipping_excluding_vat' );
		$goods_vat_total    = $this->sum_display_column( $display_lines, 'goods_vat' );
		$shipping_vat_total = $this->sum_display_column( $display_lines, 'shipping_vat' );
		$total_excluding    = $this->round_money( $goods_total + $shipping_total );
		$total_vat          = $this->round_money( $goods_vat_total + $shipping_vat_total );
		$total_including    = $this->round_money( $total_excluding + $total_vat );

		ob_start();
		?>
		<div class="wcprsv-breakdown" data-wcprsv-breakdown="1">
			<div class="wcprsv-breakdown__title"><?php echo esc_html__( 'BTW-specificatie', 'wc-pro-rata-shipping-vat' ); ?></div>

			<div class="wcprsv-summary" role="table" aria-label="<?php echo esc_attr__( 'BTW-specificatie', 'wc-pro-rata-shipping-vat' ); ?>">
				<div class="wcprsv-summary__row wcprsv-summary__row--head" role="row">
					<div role="columnheader"><?php echo esc_html__( 'Tarief', 'wc-pro-rata-shipping-vat' ); ?></div>
					<div role="columnheader"><?php echo esc_html__( 'Goederen', 'wc-pro-rata-shipping-vat' ); ?></div>
					<div role="columnheader"><?php echo esc_html__( 'Verzending', 'wc-pro-rata-shipping-vat' ); ?></div>
					<div role="columnheader"><?php echo esc_html__( 'BTW', 'wc-pro-rata-shipping-vat' ); ?></div>
				</div>
				<?php foreach ( $display_lines as $line ) : ?>
					<div class="wcprsv-summary__row" role="row">
						<div role="cell"><?php echo esc_html( $this->format_vat_rate( $line['vat_rate'] ) ); ?></div>
						<div role="cell"><?php echo wp_kses_post( wc_price( $line['goods_amount_ex_vat'] ) ); ?></div>
						<div role="cell"><?php echo wp_kses_post( wc_price( $line['shipping_excluding_vat'] ) ); ?></div>
						<div role="cell"><?php echo wp_kses_post( wc_price( $line['total_vat'] ) ); ?></div>
					</div>
				<?php endforeach; ?>
			</div>

			<div class="wcprsv-totals">
				<div class="wcprsv-totals__row">
					<span><?php echo esc_html__( 'Totaal excl. BTW', 'wc-pro-rata-shipping-vat' ); ?></span>
					<strong><?php echo wp_kses_post( wc_price( $total_excluding ) ); ?></strong>
				</div>
				<div class="wcprsv-totals__row">
					<span><?php echo esc_html__( 'Totaal BTW', 'wc-pro-rata-shipping-vat' ); ?></span>
					<strong><?php echo wp_kses_post( wc_price( $total_vat ) ); ?></strong>
				</div>
				<div class="wcprsv-totals__row wcprsv-totals__row--grand">
					<span><?php echo esc_html__( 'Totaal incl. BTW', 'wc-pro-rata-shipping-vat' ); ?></span>
					<strong><?php echo wp_kses_post( wc_price( $total_including ) ); ?></strong>
				</div>
			</div>

			<details class="wcprsv-details">
				<summary><?php echo esc_html__( 'Toon berekening', 'wc-pro-rata-shipping-vat' ); ?></summary>
				<div class="wcprsv-detail-lines">
					<?php foreach ( $display_lines as $line ) : ?>
						<div class="wcprsv-detail-line">
							<div class="wcprsv-detail-line__title"><?php echo esc_html( $this->format_vat_rate( $line['vat_rate'] ) ); ?></div>
							<div><span><?php echo esc_html__( 'Goederen excl. BTW', 'wc-pro-rata-shipping-vat' ); ?></span><strong><?php echo wp_kses_post( wc_price( $line['goods_amount_ex_vat'] ) ); ?></strong></div>
							<div><span><?php echo esc_html__( 'Verzending excl. BTW', 'wc-pro-rata-shipping-vat' ); ?></span><strong><?php echo wp_kses_post( wc_price( $line['shipping_excluding_vat'] ) ); ?></strong></div>
							<div><span><?php echo esc_html__( 'BTW goederen', 'wc-pro-rata-shipping-vat' ); ?></span><strong><?php echo wp_kses_post( wc_price( $line['goods_vat'] ) ); ?></strong></div>
							<div><span><?php echo esc_html__( 'BTW verzending', 'wc-pro-rata-shipping-vat' ); ?></span><strong><?php echo wp_kses_post( wc_price( $line['shipping_vat'] ) ); ?></strong></div>
							<div><span><?php echo esc_html__( 'Incl. BTW', 'wc-pro-rata-shipping-vat' ); ?></span><strong><?php echo wp_kses_post( wc_price( $line['including_vat'] ) ); ?></strong></div>
						</div>
					<?php endforeach; ?>
				</div>
			</details>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Build a PDF-friendly VAT breakdown table.
	 *
	 * @param array    $breakdown Pro-rata breakdown.
	 * @param WC_Order $order Order object.
	 * @return string
	 */
	private function get_pdf_breakdown_html( array $breakdown, $order ) {
		$display_lines      = $this->get_display_lines( $breakdown['lines'], $breakdown, $order );
		$goods_total        = $this->sum_display_column( $display_lines, 'goods_amount_ex_vat' );
		$shipping_total     = $this->sum_display_column( $display_lines, 'shipping_excluding_vat' );
		$goods_vat_total    = $this->sum_display_column( $display_lines, 'goods_vat' );
		$shipping_vat_total = $this->sum_display_column( $display_lines, 'shipping_vat' );
		$total_excluding    = $this->round_money( $goods_total + $shipping_total );
		$total_vat          = $this->round_money( $goods_vat_total + $shipping_vat_total );
		$total_including    = $this->round_money( $total_excluding + $total_vat );

		ob_start();
		?>
		<div class="wcprsv-pdf-breakdown" style="margin-top: 18px;">
			<h3 style="margin: 0 0 8px;"><?php echo esc_html__( 'BTW-specificatie', 'wc-pro-rata-shipping-vat' ); ?></h3>
			<table style="width: 100%; border-collapse: collapse; font-size: 10px;">
				<thead>
					<tr>
						<th style="border-bottom: 1px solid #999; text-align: left;"><?php echo esc_html__( 'Tarief', 'wc-pro-rata-shipping-vat' ); ?></th>
						<th style="border-bottom: 1px solid #999; text-align: right;"><?php echo esc_html__( 'Goederen ex. BTW', 'wc-pro-rata-shipping-vat' ); ?></th>
						<th style="border-bottom: 1px solid #999; text-align: right;"><?php echo esc_html__( 'Verzending ex. BTW', 'wc-pro-rata-shipping-vat' ); ?></th>
						<th style="border-bottom: 1px solid #999; text-align: right;"><?php echo esc_html__( 'BTW goederen', 'wc-pro-rata-shipping-vat' ); ?></th>
						<th style="border-bottom: 1px solid #999; text-align: right;"><?php echo esc_html__( 'BTW verzending', 'wc-pro-rata-shipping-vat' ); ?></th>
						<th style="border-bottom: 1px solid #999; text-align: right;"><?php echo esc_html__( 'Incl. BTW', 'wc-pro-rata-shipping-vat' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $display_lines as $line ) : ?>
						<tr>
							<td style="padding-top: 4px;"><?php echo esc_html( $this->format_vat_rate( $line['vat_rate'] ) ); ?></td>
							<td style="padding-top: 4px; text-align: right;"><?php echo wp_kses_post( wc_price( $line['goods_amount_ex_vat'] ) ); ?></td>
							<td style="padding-top: 4px; text-align: right;"><?php echo wp_kses_post( wc_price( $line['shipping_excluding_vat'] ) ); ?></td>
							<td style="padding-top: 4px; text-align: right;"><?php echo wp_kses_post( wc_price( $line['goods_vat'] ) ); ?></td>
							<td style="padding-top: 4px; text-align: right;"><?php echo wp_kses_post( wc_price( $line['shipping_vat'] ) ); ?></td>
							<td style="padding-top: 4px; text-align: right;"><?php echo wp_kses_post( wc_price( $line['including_vat'] ) ); ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
				<tfoot>
					<tr>
						<th style="border-top: 1px solid #999; padding-top: 5px; text-align: left;"><?php echo esc_html__( 'Totaal', 'wc-pro-rata-shipping-vat' ); ?></th>
						<th style="border-top: 1px solid #999; padding-top: 5px; text-align: right;"><?php echo wp_kses_post( wc_price( $goods_total ) ); ?></th>
						<th style="border-top: 1px solid #999; padding-top: 5px; text-align: right;"><?php echo wp_kses_post( wc_price( $shipping_total ) ); ?></th>
						<th style="border-top: 1px solid #999; padding-top: 5px; text-align: right;"><?php echo wp_kses_post( wc_price( $goods_vat_total ) ); ?></th>
						<th style="border-top: 1px solid #999; padding-top: 5px; text-align: right;"><?php echo wp_kses_post( wc_price( $shipping_vat_total ) ); ?></th>
						<th style="border-top: 1px solid #999; padding-top: 5px; text-align: right;"><?php echo wp_kses_post( wc_price( $total_including ) ); ?></th>
					</tr>
					<tr>
						<td colspan="5" style="padding-top: 5px; text-align: right;"><?php echo esc_html__( 'Totaal excl. BTW', 'wc-pro-rata-shipping-vat' ); ?></td>
						<td style="padding-top: 5px; text-align: right;"><?php echo wp_kses_post( wc_price( $total_excluding ) ); ?></td>
					</tr>
					<tr>
						<td colspan="5" style="text-align: right;"><?php echo esc_html__( 'Totaal BTW', 'wc-pro-rata-shipping-vat' ); ?></td>
						<td style="text-align: right;"><?php echo wp_kses_post( wc_price( $total_vat ) ); ?></td>
					</tr>
				</tfoot>
			</table>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Sum goods VAT for display lines.
	 *
	 * @param array $lines Breakdown lines.
	 * @return float
	 */
	private function sum_goods_vat( array $lines ) {
		$total = 0.0;

		foreach ( $lines as $line ) {
			$total += (float) $line['goods_amount_ex_vat'] * (float) $line['vat_rate'];
		}

		return $total;
	}

	/**
	 * Build display lines using Excel-style per-cell rounding.
	 *
	 * @param array $lines Raw breakdown lines.
	 * @param array $breakdown Full breakdown totals.
	 * @return array
	 */
	private function get_display_lines( array $lines, array $breakdown, $order = null ) {
		$display_lines = array();
		$largest_key   = null;
		$largest_total = -1.0;

		foreach ( $lines as $key => $line ) {
			$goods_amount = $this->round_money( $line['goods_amount_ex_vat'] );
			$shipping_ex  = $this->round_money( $line['shipping_excluding_vat'] );
			$goods_vat    = $this->round_money( $goods_amount * $line['vat_rate'] );
			$shipping_vat = $this->round_money( $line['shipping_vat'] );
			$total_vat    = $this->round_money( $goods_vat + $shipping_vat );
			$including    = $this->round_money( $goods_amount + $shipping_ex + $total_vat );

			$display_lines[ $key ] = array(
				'vat_rate'               => (float) $line['vat_rate'],
				'goods_amount_ex_vat'    => $goods_amount,
				'shipping_excluding_vat' => $shipping_ex,
				'goods_vat'              => $goods_vat,
				'shipping_vat'           => $shipping_vat,
				'total_vat'              => $total_vat,
				'including_vat'          => $including,
			);

			if ( $including > $largest_total ) {
				$largest_key   = $key;
				$largest_total = $including;
			}
		}

		$this->reconcile_display_lines( $display_lines, $breakdown, $largest_key, $order );

		return $display_lines;
	}

	/**
	 * Reconcile rounded display cells with WooCommerce-facing totals.
	 *
	 * @param array       $display_lines Rounded display lines.
	 * @param array       $breakdown Full breakdown totals.
	 * @param string|null $largest_key Line key that receives rounding deltas.
	 * @return void
	 */
	private function reconcile_display_lines( array &$display_lines, array $breakdown, $largest_key, $order = null ) {
		if ( empty( $display_lines ) || null === $largest_key || ! isset( $display_lines[ $largest_key ] ) ) {
			return;
		}

		$cart_total_including     = is_a( $order, 'WC_Order' ) ? 0.0 : $this->get_cart_total_including_vat();
		$target_shipping_ex       = $this->round_money( $breakdown['shipping_excluding_vat'] );
		$target_shipping_vat      = $this->round_money( $breakdown['shipping_including_vat'] - $breakdown['shipping_excluding_vat'] );
		$target_shipping_incl     = $this->round_money( $breakdown['shipping_including_vat'] );
		$current_shipping_ex      = $this->sum_display_column( $display_lines, 'shipping_excluding_vat' );
		$current_shipping_vat     = $this->sum_display_column( $display_lines, 'shipping_vat' );
		$shipping_incl_difference = $this->round_money( $target_shipping_incl - $current_shipping_ex - $current_shipping_vat );

		$display_lines[ $largest_key ]['shipping_vat'] = $this->round_money(
			$display_lines[ $largest_key ]['shipping_vat'] + $shipping_incl_difference
		);

		$shipping_ex_difference = $this->round_money( $target_shipping_ex - $current_shipping_ex );

		if ( 0.0 !== $shipping_ex_difference ) {
			$display_lines[ $largest_key ]['shipping_excluding_vat'] = $this->round_money(
				$display_lines[ $largest_key ]['shipping_excluding_vat'] + $shipping_ex_difference
			);
		}

		$shipping_vat_difference = $this->round_money( $target_shipping_vat - $this->sum_display_column( $display_lines, 'shipping_vat' ) );

		if ( 0.0 !== $shipping_vat_difference ) {
			$display_lines[ $largest_key ]['shipping_vat'] = $this->round_money(
				$display_lines[ $largest_key ]['shipping_vat'] + $shipping_vat_difference
			);
		}

		$target_goods_total = $cart_total_including > 0 ? $this->round_money( $cart_total_including - $target_shipping_incl ) : $this->sum_display_column( $display_lines, 'goods_amount_ex_vat' ) + $this->sum_display_column( $display_lines, 'goods_vat' );
		$current_goods_total = $this->round_money(
			$this->sum_display_column( $display_lines, 'goods_amount_ex_vat' ) + $this->sum_display_column( $display_lines, 'goods_vat' )
		);
		$goods_vat_difference = $this->round_money( $target_goods_total - $current_goods_total );

		if ( 0.0 !== $goods_vat_difference ) {
			$display_lines[ $largest_key ]['goods_vat'] = $this->round_money(
				$display_lines[ $largest_key ]['goods_vat'] + $goods_vat_difference
			);
		}

		foreach ( $display_lines as &$line ) {
			$line['total_vat']     = $this->round_money( $line['goods_vat'] + $line['shipping_vat'] );
			$line['including_vat'] = $this->round_money( $line['goods_amount_ex_vat'] + $line['shipping_excluding_vat'] + $line['total_vat'] );
		}
		unset( $line );
	}

	/**
	 * Sum a rounded display column.
	 *
	 * @param array  $lines Display lines.
	 * @param string $column Column name.
	 * @return float
	 */
	private function sum_display_column( array $lines, $column ) {
		$total = 0.0;

		foreach ( $lines as $line ) {
			$total += (float) $line[ $column ];
		}

		return $this->round_money( $total );
	}

	/**
	 * Round a monetary display value like Excel ROUND(cell, 2).
	 *
	 * @param float $value Raw value.
	 * @return float
	 */
	private function round_money( $value ) {
		return round( (float) $value, wc_get_price_decimals() );
	}

	/**
	 * Get the current cart total including VAT.
	 *
	 * @return float
	 */
	private function get_cart_total_including_vat() {
		if ( ! WC()->cart ) {
			return 0.0;
		}

		return $this->round_money( (float) WC()->cart->get_total( 'edit' ) );
	}

	/**
	 * Get a pro-rata breakdown from order meta or order line items.
	 *
	 * @param WC_Order $order Order object.
	 * @return array
	 */
	private function get_order_breakdown( $order ) {
		$breakdown = $order->get_meta( '_wcprsv_breakdown' );

		if ( ! empty( $breakdown['lines'] ) ) {
			return $breakdown;
		}

		$breakdown = $this->get_breakdown_from_order_shipping_items( $order );

		if ( ! empty( $breakdown['lines'] ) ) {
			return $breakdown;
		}

		$goods_by_tax_rate = $this->get_order_goods_by_tax_rate( $order );
		$shipping_incl     = $this->round_money( (float) $order->get_shipping_total() + (float) $order->get_shipping_tax() );

		if ( empty( $goods_by_tax_rate ) || $shipping_incl <= 0 ) {
			return array();
		}

		return $this->calculator->calculate_from_including_vat( $shipping_incl, $goods_by_tax_rate, wc_get_price_decimals() );
	}

	/**
	 * Combine breakdown metadata stored on order shipping items.
	 *
	 * @param WC_Order $order Order object.
	 * @return array
	 */
	private function get_breakdown_from_order_shipping_items( $order ) {
		$combined = array(
			'shipping_including_vat' => 0.0,
			'shipping_excluding_vat' => 0.0,
			'taxes'                  => array(),
			'lines'                  => array(),
		);

		foreach ( $order->get_items( 'shipping' ) as $item ) {
			$breakdown = $item->get_meta( '_wcprsv_breakdown' );

			if ( empty( $breakdown['lines'] ) ) {
				continue;
			}

			$combined['shipping_including_vat'] += (float) $breakdown['shipping_including_vat'];
			$combined['shipping_excluding_vat'] += (float) $breakdown['shipping_excluding_vat'];

			foreach ( $breakdown['taxes'] as $tax_rate_id => $tax_amount ) {
				if ( ! isset( $combined['taxes'][ $tax_rate_id ] ) ) {
					$combined['taxes'][ $tax_rate_id ] = 0.0;
				}

				$combined['taxes'][ $tax_rate_id ] += (float) $tax_amount;
			}

			foreach ( $breakdown['lines'] as $tax_rate_id => $line ) {
				if ( ! isset( $combined['lines'][ $tax_rate_id ] ) ) {
					$combined['lines'][ $tax_rate_id ] = $line;
					continue;
				}

				$combined['lines'][ $tax_rate_id ]['goods_amount_ex_vat']    += (float) $line['goods_amount_ex_vat'];
				$combined['lines'][ $tax_rate_id ]['shipping_excluding_vat'] += (float) $line['shipping_excluding_vat'];
				$combined['lines'][ $tax_rate_id ]['shipping_vat']           += (float) $line['shipping_vat'];
				$combined['lines'][ $tax_rate_id ]['shipping_including_vat'] += (float) $line['shipping_including_vat'];
			}
		}

		return $combined;
	}

	/**
	 * Apply pro-rata shipping tax amounts to WooCommerce order tax lines.
	 *
	 * @param WC_Order $order Order object.
	 * @param array    $breakdown Pro-rata breakdown.
	 * @return void
	 */
	private function apply_order_tax_lines( $order, array $breakdown ) {
		if ( empty( $breakdown['taxes'] ) ) {
			return;
		}

		$tax_items_by_rate_id = array();

		foreach ( $order->get_items( 'tax' ) as $tax_item ) {
			$tax_items_by_rate_id[ (string) $tax_item->get_rate_id() ] = $tax_item;

			if ( method_exists( $tax_item, 'set_shipping_tax_total' ) ) {
				$tax_item->set_shipping_tax_total( 0 );
			}
		}

		foreach ( $breakdown['taxes'] as $rate_id => $shipping_tax_amount ) {
			$rate_id = (string) $rate_id;

			if ( ! isset( $tax_items_by_rate_id[ $rate_id ] ) ) {
				$tax_item = $this->create_order_tax_item( $rate_id );
				$order->add_item( $tax_item );
				$tax_items_by_rate_id[ $rate_id ] = $tax_item;
			}

			if ( method_exists( $tax_items_by_rate_id[ $rate_id ], 'set_shipping_tax_total' ) ) {
				$tax_items_by_rate_id[ $rate_id ]->set_shipping_tax_total( wc_format_decimal( $shipping_tax_amount, wc_get_price_decimals() ) );
			}
		}

		$this->debug_log(
			'apply_order_tax_lines',
			array(
				'order_id'   => $order->get_id(),
				'breakdown_taxes' => $breakdown['taxes'],
				'order_tax_items' => $this->summarize_order_tax_items( $order ),
			)
		);
	}

	/**
	 * Create an order tax item for a WooCommerce tax rate.
	 *
	 * @param string $rate_id Tax rate ID.
	 * @return WC_Order_Item_Tax
	 */
	private function create_order_tax_item( $rate_id ) {
		$tax_rate = class_exists( 'WC_Tax' ) && method_exists( 'WC_Tax', '_get_tax_rate' ) ? WC_Tax::_get_tax_rate( $rate_id ) : array();
		$tax_item = new WC_Order_Item_Tax();

		$tax_item->set_rate_id( (int) $rate_id );
		$tax_item->set_label( ! empty( $tax_rate['tax_rate_name'] ) ? $tax_rate['tax_rate_name'] : __( 'VAT', 'wc-pro-rata-shipping-vat' ) );
		if ( method_exists( 'WC_Tax', 'get_rate_code' ) ) {
			$tax_item->set_rate_code( WC_Tax::get_rate_code( $rate_id ) );
		}
		$tax_item->set_rate_percent( ! empty( $tax_rate['tax_rate'] ) ? (float) $tax_rate['tax_rate'] : 0 );
		$tax_item->set_compound( ! empty( $tax_rate['tax_rate_compound'] ) );
		$tax_item->set_tax_total( 0 );

		if ( method_exists( $tax_item, 'set_shipping_tax_total' ) ) {
			$tax_item->set_shipping_tax_total( 0 );
		}

		return $tax_item;
	}

	/**
	 * Write a debug log entry when enabled.
	 *
	 * @param string $stage Stage name.
	 * @param array  $data Debug data.
	 * @return void
	 */
	private function debug_log( $stage, array $data = array() ) {
		if ( ! $this->settings->is_debug_enabled() ) {
			return;
		}

		$payload = array(
			'stage' => $stage,
			'data'  => $this->sanitize_debug_data( $data ),
		);

		try {
			$message = wp_json_encode( $payload );

			if ( ! is_string( $message ) || '' === $message ) {
				$message = wp_json_encode(
					array(
						'stage' => $stage,
						'error' => 'Could not encode debug payload.',
					)
				);
			}

			if ( function_exists( 'wc_get_logger' ) ) {
				wc_get_logger()->debug( $message, array( 'source' => 'wc-pro-rata-shipping-vat' ) );
				return;
			}

			error_log( '[wc-pro-rata-shipping-vat] ' . $message ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
		} catch ( Throwable $e ) {
			error_log( '[wc-pro-rata-shipping-vat] debug logging failed: ' . $e->getMessage() ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
		}
	}

	/**
	 * Sanitize debug data to keep checkout logging compact and safe.
	 *
	 * @param mixed $data Raw debug data.
	 * @param int   $depth Current recursion depth.
	 * @return mixed
	 */
	private function sanitize_debug_data( $data, $depth = 0 ) {
		if ( $depth > 6 ) {
			return '[max-depth]';
		}

		if ( is_null( $data ) || is_scalar( $data ) ) {
			return $data;
		}

		if ( is_object( $data ) ) {
			return array(
				'object' => get_class( $data ),
			);
		}

		if ( ! is_array( $data ) ) {
			return '[' . gettype( $data ) . ']';
		}

		$output = array();
		$count  = 0;

		foreach ( $data as $key => $value ) {
			if ( $count >= 80 ) {
				$output['__truncated'] = count( $data ) - $count;
				break;
			}

			$output[ $key ] = $this->sanitize_debug_data( $value, $depth + 1 );
			$count++;
		}

		return $output;
	}

	/**
	 * Summarize shipping packages for debug output.
	 *
	 * @param array $packages Shipping packages.
	 * @return array
	 */
	private function summarize_packages( array $packages ) {
		$summary = array();

		foreach ( $packages as $index => $package ) {
			$summary[ $index ] = $this->summarize_package( $package );
		}

		return $summary;
	}

	/**
	 * Summarize one shipping package for debug output.
	 *
	 * @param array $package Shipping package.
	 * @return array
	 */
	private function summarize_package( array $package ) {
		$rates = array();

		if ( ! empty( $package['rates'] ) ) {
			foreach ( $package['rates'] as $rate_id => $rate ) {
				if ( ! is_a( $rate, 'WC_Shipping_Rate' ) ) {
					continue;
				}

				$rates[ $rate_id ] = array(
					'id'     => $rate->get_id(),
					'label'  => $rate->get_label(),
					'cost'   => $rate->get_cost(),
					'taxes'  => $rate->get_taxes(),
				);
			}
		}

		return array(
			'contents_count' => ! empty( $package['contents'] ) && is_array( $package['contents'] ) ? count( $package['contents'] ) : 0,
			'rates'          => $rates,
		);
	}

	/**
	 * Summarize order tax items for debug output.
	 *
	 * @param WC_Order $order Order object.
	 * @return array
	 */
	private function summarize_order_tax_items( $order ) {
		$items = array();

		foreach ( $order->get_items( 'tax' ) as $item_id => $item ) {
			$items[ $item_id ] = array(
				'rate_id'            => $item->get_rate_id(),
				'label'              => $item->get_label(),
				'tax_total'          => $item->get_tax_total(),
				'shipping_tax_total' => method_exists( $item, 'get_shipping_tax_total' ) ? $item->get_shipping_tax_total() : null,
			);
		}

		return $items;
	}

	/**
	 * Group order item totals by tax rate ID.
	 *
	 * @param WC_Order $order Order object.
	 * @return array
	 */
	private function get_order_goods_by_tax_rate( $order ) {
		$goods_by_tax_rate = array();

		foreach ( $order->get_items( 'line_item' ) as $item ) {
			$line_total = (float) $item->get_total();
			$taxes      = $item->get_taxes();
			$tax_totals = isset( $taxes['total'] ) && is_array( $taxes['total'] ) ? array_filter( $taxes['total'] ) : array();

			if ( empty( $tax_totals ) ) {
				$this->add_goods_amount( $goods_by_tax_rate, '0', 0.0, $line_total );
				continue;
			}

			foreach ( $tax_totals as $rate_id => $tax_amount ) {
				$rate = $this->get_tax_rate_decimal_by_id( $rate_id );
				$this->add_goods_amount( $goods_by_tax_rate, $rate_id, $rate, $line_total );
			}
		}

		return $goods_by_tax_rate;
	}

	/**
	 * Get decimal tax rate by WooCommerce tax rate ID.
	 *
	 * @param string|int $rate_id Tax rate ID.
	 * @return float
	 */
	private function get_tax_rate_decimal_by_id( $rate_id ) {
		if ( ! class_exists( 'WC_Tax' ) || ! method_exists( 'WC_Tax', '_get_tax_rate' ) ) {
			return 0.0;
		}

		$tax_rate = WC_Tax::_get_tax_rate( $rate_id );

		if ( empty( $tax_rate['tax_rate'] ) ) {
			return 0.0;
		}

		return max( 0.0, (float) $tax_rate['tax_rate'] / 100 );
	}

	/**
	 * Format a decimal VAT rate for display.
	 *
	 * @param float $rate Decimal VAT rate.
	 * @return string
	 */
	private function format_vat_rate( $rate ) {
		return wc_format_localized_decimal( (float) $rate * 100 ) . '%';
	}

	/**
	 * Group package contents by tax rate ID.
	 *
	 * @param array $package Package data.
	 * @return array
	 */
	private function get_goods_by_tax_rate( $package ) {
		$goods_by_tax_rate = array();

		if ( empty( $package['contents'] ) || ! is_array( $package['contents'] ) ) {
			return $goods_by_tax_rate;
		}

		foreach ( $package['contents'] as $cart_item ) {
			if ( empty( $cart_item['data'] ) || ! is_a( $cart_item['data'], 'WC_Product' ) ) {
				continue;
			}

			$product = $cart_item['data'];

			if ( ! $product->is_taxable() ) {
				$this->add_goods_amount( $goods_by_tax_rate, '0', 0.0, $this->get_line_amount_excluding_vat( $cart_item ) );
				continue;
			}

			$tax_rates = WC_Tax::get_rates( $product->get_tax_class() );
			$rate_id   = $this->get_primary_tax_rate_id( $tax_rates );
			$rate      = $this->get_primary_tax_rate_percentage( $tax_rates );
			$amount    = $this->get_line_amount_excluding_vat( $cart_item );

			$this->add_goods_amount( $goods_by_tax_rate, $rate_id, $rate, $amount );
		}

		return array_filter(
			$goods_by_tax_rate,
			static function ( $data ) {
				return $data['amount_ex_vat'] > 0;
			}
		);
	}

	/**
	 * Get a cart line amount excluding VAT after discounts where available.
	 *
	 * @param array $cart_item Cart item.
	 * @return float
	 */
	private function get_line_amount_excluding_vat( $cart_item ) {
		if ( isset( $cart_item['line_total'] ) ) {
			return max( 0.0, (float) $cart_item['line_total'] );
		}

		if ( isset( $cart_item['data'], $cart_item['quantity'] ) && is_a( $cart_item['data'], 'WC_Product' ) ) {
			return max( 0.0, (float) $cart_item['data']->get_price() * (float) $cart_item['quantity'] );
		}

		return 0.0;
	}

	/**
	 * Add a goods amount to a tax bucket.
	 *
	 * @param array  $goods_by_tax_rate Goods buckets.
	 * @param string $rate_id Tax rate ID.
	 * @param float  $rate Tax rate as decimal.
	 * @param float  $amount Amount excluding VAT.
	 * @return void
	 */
	private function add_goods_amount( array &$goods_by_tax_rate, $rate_id, $rate, $amount ) {
		$rate_id = (string) $rate_id;

		if ( ! isset( $goods_by_tax_rate[ $rate_id ] ) ) {
			$goods_by_tax_rate[ $rate_id ] = array(
				'amount_ex_vat' => 0.0,
				'rate'          => (float) $rate,
			);
		}

		$goods_by_tax_rate[ $rate_id ]['amount_ex_vat'] += max( 0.0, (float) $amount );
	}

	/**
	 * Pick the primary WooCommerce tax rate ID for a tax class.
	 *
	 * @param array $tax_rates WooCommerce tax rates.
	 * @return string
	 */
	private function get_primary_tax_rate_id( $tax_rates ) {
		if ( empty( $tax_rates ) || ! is_array( $tax_rates ) ) {
			return '0';
		}

		$rate_ids = array_keys( $tax_rates );

		return (string) reset( $rate_ids );
	}

	/**
	 * Pick the primary WooCommerce tax rate percentage for a tax class.
	 *
	 * @param array $tax_rates WooCommerce tax rates.
	 * @return float Decimal VAT rate.
	 */
	private function get_primary_tax_rate_percentage( $tax_rates ) {
		if ( empty( $tax_rates ) || ! is_array( $tax_rates ) ) {
			return 0.0;
		}

		$first_rate = reset( $tax_rates );
		$percentage = isset( $first_rate['rate'] ) ? (float) $first_rate['rate'] : 0.0;

		return max( 0.0, $percentage / 100 );
	}
}
