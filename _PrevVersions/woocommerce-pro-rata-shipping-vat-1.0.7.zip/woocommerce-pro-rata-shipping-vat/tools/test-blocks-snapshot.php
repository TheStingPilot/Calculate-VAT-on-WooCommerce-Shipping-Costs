<?php
/**
 * Regression test for WooCommerce Blocks snapshots when the REST cart is empty.
 *
 * Run from the plugin root:
 * php src/tools/test-blocks-snapshot.php
 *
 * @package WCProRataShippingVAT
 */

define( 'WCPRSV_ALLOW_STANDALONE', true );

if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ );
}

if ( ! function_exists( 'wc_get_price_decimals' ) ) {
	function wc_get_price_decimals() {
		return 2;
	}
}

if ( ! function_exists( 'absint' ) ) {
	function absint( $value ) {
		return abs( (int) $value );
	}
}

if ( ! function_exists( 'wp_json_encode' ) ) {
	function wp_json_encode( $value ) {
		return json_encode( $value );
	}
}

if ( ! function_exists( '__' ) ) {
	function __( $text ) {
		return $text;
	}
}

require_once dirname( __DIR__ ) . '/includes/class-wcprsv-calculator.php';
require_once dirname( __DIR__ ) . '/includes/class-wcprsv-settings.php';
require_once dirname( __DIR__ ) . '/includes/class-wcprsv-plugin.php';

echo 'Running Blocks snapshot tests...' . PHP_EOL;

$breakdown = array(
	'shipping_including_vat' => 6.95,
	'shipping_excluding_vat' => 5.74,
	'taxes'                  => array(
		'1' => 1.21,
	),
	'lines'                  => array(
		'1' => array(
			'goods_amount_ex_vat'       => 9.50,
			'vat_rate'                  => 0.21,
			'share'                     => 1,
			'shipping_excluding_vat'    => 5.74,
			'shipping_vat'              => 1.21,
			'shipping_including_vat'    => 6.95,
			'unrounded_excluding_vat'   => 5.74380165,
			'unrounded_vat'             => 1.20619835,
			'unrounded_including_vat'   => 6.95,
		),
	),
);

$reflection = new ReflectionClass( 'WCPRSV_Plugin' );
$plugin = $reflection->newInstanceWithoutConstructor();

$calculator_property = $reflection->getProperty( 'calculator' );
$calculator_property->setAccessible( true );
$calculator_property->setValue( $plugin, new WCPRSV_Calculator() );

$enrich_method = $reflection->getMethod( 'add_breakdown_to_store_api_rate' );
$enrich_method->setAccessible( true );

$rate_data = array(
	'rate_id' => 'flat_rate:1',
	'selected' => true,
	'price'   => '574',
	'taxes'   => array(
		array(
			'price' => '121',
			'rate'  => '21',
		),
	),
);

$enrich_method->invokeArgs( $plugin, array( &$rate_data, $breakdown ) );

if ( empty( $rate_data['_wcprsv_breakdown']['lines'] ) || empty( $rate_data['meta_data'][0]['value'] ) ) {
	echo json_encode( $rate_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) . PHP_EOL;
	fwrite( STDERR, 'Blocks snapshot test failed: Store API rate was not enriched with breakdown metadata.' . PHP_EOL );
	exit( 1 );
}

$snapshot = array(
	'totals'        => array(
		'total_shipping'       => '574',
		'total_shipping_tax'   => '121',
		'currency_minor_unit'  => 2,
		'tax_lines'            => array(
			array(
				'name'  => '21% BTW Nederland',
				'price' => '321',
				'rate'  => '21',
			),
		),
	),
	'shippingRates' => array(
		array(
			'package_id' => 0,
			'shipping_rates' => array(
				$rate_data,
			),
		),
	),
	'cartData'      => array(
		'items'  => array(
			array(
				'totals' => array(
					'line_subtotal'     => '950',
					'line_subtotal_tax' => '200',
				),
			),
		),
		'totals' => array(
			'currency_minor_unit' => 2,
		),
	),
);

$method = $reflection->getMethod( 'calculate_breakdown_from_blocks_snapshot' );
$method->setAccessible( true );

$result = $method->invoke( $plugin, $snapshot );
$expected = $breakdown;
$expected['lines']['1']['goods_vat'] = 2.00;

if ( $expected !== $result ) {
	echo json_encode( $result, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) . PHP_EOL;
	fwrite( STDERR, 'Blocks snapshot test failed: paid shipping breakdown was not recovered.' . PHP_EOL );
	exit( 1 );
}

$int_snapshot = $snapshot;
$int_snapshot['totals']['total_shipping']     = 574;
$int_snapshot['totals']['total_shipping_tax'] = 121;
$int_snapshot['totals']['tax_lines'][0]['price'] = 321;
$int_snapshot['shippingRates'][0]['shipping_rates'][0]['price'] = 574;
$int_snapshot['shippingRates'][0]['shipping_rates'][0]['taxes'][0]['price'] = 121;

$result = $method->invoke( $plugin, $int_snapshot );

if ( $expected !== $result ) {
	echo json_encode( $result, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) . PHP_EOL;
	fwrite( STDERR, 'Blocks snapshot test failed: integer Store API amounts were not parsed as minor units.' . PHP_EOL );
	exit( 1 );
}

$metadata_lost_snapshot = $snapshot;
unset( $metadata_lost_snapshot['shippingRates'][0]['shipping_rates'][0]['_wcprsv_breakdown'] );
$metadata_lost_snapshot['shippingRates'][0]['shipping_rates'][0]['meta_data'] = array();

$result = $method->invoke( $plugin, $metadata_lost_snapshot );
$rebuilt_line = ! empty( $result['lines'] ) ? reset( $result['lines'] ) : array();

if (
	6.95 !== ( $result['shipping_including_vat'] ?? null ) ||
	5.74 !== ( $result['shipping_excluding_vat'] ?? null ) ||
	9.50 !== ( $rebuilt_line['goods_amount_ex_vat'] ?? null ) ||
	1.21 !== ( $rebuilt_line['shipping_vat'] ?? null ) ||
	2.00 !== ( $rebuilt_line['goods_vat'] ?? null )
) {
	echo json_encode( $result, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) . PHP_EOL;
	fwrite( STDERR, 'Blocks snapshot test failed: paid shipping should be reconstructed when Blocks metadata is missing.' . PHP_EOL );
	exit( 1 );
}

$snapshot['shippingRates'][0]['shipping_rates'] = array(
	array_merge(
		$rate_data,
		array(
			'selected' => false,
		)
	),
	array(
		'rate_id'   => 'local_pickup:1',
		'selected'  => true,
		'price'     => '0',
		'taxes'     => array(),
		'meta_data' => array(),
	),
);
$snapshot['totals']['total_shipping'] = '0';
$snapshot['totals']['total_shipping_tax'] = '0';
$snapshot['totals']['tax_lines'][0]['price'] = '200';
$result = $method->invoke( $plugin, $snapshot );
$free_line = ! empty( $result['lines'] ) ? reset( $result['lines'] ) : array();

if (
	0.0 !== ( $result['shipping_including_vat'] ?? null ) ||
	0.0 !== ( $result['shipping_excluding_vat'] ?? null ) ||
	9.50 !== ( $free_line['goods_amount_ex_vat'] ?? null ) ||
	0.0 !== ( $free_line['shipping_excluding_vat'] ?? null ) ||
	0.0 !== ( $free_line['shipping_vat'] ?? null ) ||
	2.00 !== ( $free_line['goods_vat'] ?? null )
) {
	echo json_encode( $result, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) . PHP_EOL;
	fwrite( STDERR, 'Blocks snapshot test failed: free shipping should return a zero-shipping VAT specification.' . PHP_EOL );
	exit( 1 );
}

$stale_paid_rate_snapshot = $snapshot;
$stale_paid_rate_snapshot['totals']['total_shipping']     = '0';
$stale_paid_rate_snapshot['totals']['total_shipping_tax'] = '0';
$stale_paid_rate_snapshot['shippingRates'][0]['shipping_rates'] = array(
	array_merge(
		$rate_data,
		array(
			'selected' => true,
		)
	),
);

$result = $method->invoke( $plugin, $stale_paid_rate_snapshot );
$stale_free_line = ! empty( $result['lines'] ) ? reset( $result['lines'] ) : array();

if (
	0.0 !== ( $result['shipping_including_vat'] ?? null ) ||
	0.0 !== ( $stale_free_line['shipping_excluding_vat'] ?? null ) ||
	0.0 !== ( $stale_free_line['shipping_vat'] ?? null ) ||
	2.00 !== ( $stale_free_line['goods_vat'] ?? null )
) {
	echo json_encode( $result, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) . PHP_EOL;
	fwrite( STDERR, 'Blocks snapshot test failed: zero Blocks shipping totals must ignore stale paid rate metadata.' . PHP_EOL );
	exit( 1 );
}

echo 'Blocks snapshot tests passed.' . PHP_EOL;
