<?php
/**
 * Regression test for WooCommerce Blocks snapshots when the REST cart is empty.
 *
 * Run from the plugin root:
 * php src/tools/test-blocks-snapshot.php
 *
 * @package WCProRataShippingVAT
 */

define( 'WCPRSV_ALLOW_STANDALONE', true );

if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ );
}

if ( ! function_exists( 'wc_get_price_decimals' ) ) {
	function wc_get_price_decimals() {
		return 2;
	}
}

if ( ! function_exists( 'absint' ) ) {
	function absint( $value ) {
		return abs( (int) $value );
	}
}

if ( ! function_exists( 'wp_json_encode' ) ) {
	function wp_json_encode( $value ) {
		return json_encode( $value );
	}
}

if ( ! function_exists( '__' ) ) {
	function __( $text ) {
		return $text;
	}
}

require_once dirname( __DIR__ ) . '/includes/class-wcprsv-calculator.php';
require_once dirname( __DIR__ ) . '/includes/class-wcprsv-settings.php';
require_once dirname( __DIR__ ) . '/includes/class-wcprsv-plugin.php';

echo 'Running Blocks snapshot tests...' . PHP_EOL;

$breakdown = array(
	'shipping_including_vat' => 6.95,
	'shipping_excluding_vat' => 5.74,
	'taxes'                  => array(
		'1' => 1.21,
	),
	'lines'                  => array(
		'1' => array(
			'goods_amount_ex_vat'       => 9.50,
			'vat_rate'                  => 0.21,
			'share'                     => 1,
			'shipping_excluding_vat'    => 5.74,
			'shipping_vat'              => 1.21,
			'shipping_including_vat'    => 6.95,
			'unrounded_excluding_vat'   => 5.74380165,
			'unrounded_vat'             => 1.20619835,
			'unrounded_including_vat'   => 6.95,
		),
	),
);

$snapshot = array(
	'totals'        => array(
		'total_shipping'       => '574',
		'total_shipping_tax'   => '121',
		'currency_minor_unit'  => 2,
	),
	'shippingRates' => array(
		array(
			'package_id' => 0,
			'shipping_rates' => array(
				array(
					'rate_id'   => 'flat_rate:1',
					'selected'  => true,
					'meta_data' => array(
						array(
							'key'   => '_wcprsv_breakdown',
							'value' => wp_json_encode( $breakdown ),
						),
					),
				),
			),
		),
	),
);

$reflection = new ReflectionClass( 'WCPRSV_Plugin' );
$plugin = $reflection->newInstanceWithoutConstructor();

$calculator_property = $reflection->getProperty( 'calculator' );
$calculator_property->setAccessible( true );
$calculator_property->setValue( $plugin, new WCPRSV_Calculator() );

$method = $reflection->getMethod( 'calculate_breakdown_from_blocks_snapshot' );
$method->setAccessible( true );

$result = $method->invoke( $plugin, $snapshot );

if ( $breakdown !== $result ) {
	echo json_encode( $result, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) . PHP_EOL;
	fwrite( STDERR, 'Blocks snapshot test failed: paid shipping breakdown was not recovered.' . PHP_EOL );
	exit( 1 );
}

$snapshot['totals']['total_shipping'] = '0';
$snapshot['totals']['total_shipping_tax'] = '0';
$result = $method->invoke( $plugin, $snapshot );

if ( array() !== $result ) {
	echo json_encode( $result, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) . PHP_EOL;
	fwrite( STDERR, 'Blocks snapshot test failed: free shipping should not return a breakdown.' . PHP_EOL );
	exit( 1 );
}

echo 'Blocks snapshot tests passed.' . PHP_EOL;
